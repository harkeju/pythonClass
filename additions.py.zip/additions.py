'''
This calculator allows you to add any two numbers
'''
first_number = float(input("Enter a number: "))

second_number = float(input("Enter another number: "))

result = round(first_number + second_number)

print(f"{first_number} + {second_number} = {result}")
